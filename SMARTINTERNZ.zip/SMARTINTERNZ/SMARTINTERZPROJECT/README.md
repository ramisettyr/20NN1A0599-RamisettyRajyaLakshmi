# SI-GuidedProject-524684-1688207584
Suicides In India Visualizations Using Tableau

In this project, we have created dashboards and stories using Tableau for the dataset "Suicides in India 2001-2012" .
You can download the dataset from the link
https://www.kaggle.com/datasets/venkateshgopal/suicides-in-india-20012012
